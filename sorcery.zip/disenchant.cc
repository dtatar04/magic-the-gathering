#include "disenchant.h"
using namespace std;

Disenchant::Disenchant(string name, Player& p): Spell{name, p} {
    setCost(1);
    setDescription("Destroy the top enchantment on target minion");
}

void Disenchant::playCard(Player& ap, Player& tp, Minion& m, int i, int t) {
    m.removeEnchantment();
}

