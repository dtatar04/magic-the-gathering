#include "enchantment.h"

Enchantment::Enchantment(string name, Player& p): Card{name, "Enchantment", p}, atkOp{' '}, defOp{' '}, modValue{0} {

    if (name == "Giant Strength") {
        setCost(1);
        enDesc = "";
        atkOp = '+';
        defOp = '+';
        modValue = 2;

    } else if (name == "Enrage") {
        setCost(2);
        enDesc = "";
        atkOp = '*';
        defOp = '*';
        modValue = 2;

    } else if (name == "Haste") {
        setCost(1);
        enDesc = "Enchanted minion gains +1 action each turn";

    } else if (name == "Magic Fatigue") {
        setCost(0);
        enDesc = "Enchanted minion's activated ability costs 2 more";

    } else if (name == "Silence") {
        setCost(1);
        enDesc = "Enchanted minion cannot use abilities";
    }
}

Enchantment::Enchantment(Enchantment& other): Card{other.getName(), other.getType(), other.getOwner()}, 
    enDesc{other.getDescription()}, atkOp{other.getAtkOp()}, defOp{other.getDefOp()},
    modValue{other.getModValue()} {}



string Enchantment::getDescription() {
    return enDesc;
}
    
char Enchantment::getAtkOp() {
    return atkOp;
}

char Enchantment::getDefOp() {
    return defOp;
}

int Enchantment::getModValue() {
    return modValue;
}
