#include "subject.h"
#include "minion.h"

#include <algorithm>

using namespace std;

// Add new observer to observers
void Subject::attach(shared_ptr<Observer> o) {
    observers.push_back(o);
}

// Remove observer from observers
void Subject::detach(shared_ptr<Observer> o) {
    // If o is found in observers, erase it
    auto it = find(observers.begin(), observers.end(), o);
    if (it != observers.end()) {
         observers.erase(it);
    }
}

// Notify observers based on the other player's game state
void Subject::notifyObservers(State gState) {
    auto thisMin = static_cast<Minion*>(this);
    
    // Find the first observer of the other player
    for (auto &ob : observers) {
        auto observerMin = static_pointer_cast<Minion>(ob);

        // Get its first instance
        if (thisMin->getOwner().getPlayerNum() != observerMin->getOwner().getPlayerNum() ) {
            thisMin->notify( observerMin, gState );
            break;
        }
    }
}

// Get number of observers
int Subject::getNumofObservers() {
    return observers.size();
}

